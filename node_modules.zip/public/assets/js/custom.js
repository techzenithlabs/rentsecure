let getTabs=document.querySelectorAll('ul.nav.nav-pills > li');
getTabs.forEach(function(e){
    e.addEventListener('click',function(){
        let getdataattr=this.getAttribute('role')
        if(getdataattr=="landlord"){
            document.getElementById('user_type').value=getdataattr;
        }else if(getdataattr=="tenant"){
            document.getElementById('user_type').value=getdataattr;
        }
    })


})
