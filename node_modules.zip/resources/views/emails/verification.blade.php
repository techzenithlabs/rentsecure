<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Email Verification</title>
</head>
<body>
    <h2>Hello {{ $user->firstname }},</h2>
    <p>Your account has been created successfully. Please click on the following link to verify your email:</p>
    <a href="{{ route('verification.verify', ['id' => $user->id]) }}">Verify Email</a>
    <p>If you did not create an account, no further action is required.</p>
    <p>Regards,</p>
    <p>Rent Secure Pvt Ltd</p>
</body>
</html>
