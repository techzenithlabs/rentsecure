<!DOCTYPE html>
<html lang="en">
<head>
<title>Rent Secure</title>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" type="text/css" href="{{ asset('public/assets/css/bootstrap.min.css') }}">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">
<link rel="stylesheet" type="text/css" href="{{ asset('public/assets/css/owl.carousel.min.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('public/assets/css/owl.theme.default.min.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('public/assets/css/style.css') }}">
<link rel="stylesheet" type="text/css" href="{{ asset('public/assets/css/responsive.css') }}">
</head>
<body>
